# -- Import required libraries / modules:
from datetime import datetime
from pathlib import Path

from modules.export_files import export_to_csv, export_to_excel

import inspect
import logging
import os
import pandas as pd


def process_soup(soup: str, 
                 row_details: pd.DataFrame,
                 site_name: str, 
                 site_output_folder: str):
    """
    ### Summary:
        This function will process a beautiful soup input to output any data that
        the user specifies.

    ### Args:
        soup (str): 
            A beautiful soup object that needs to be processed.
        row_details (dataframe): 
            The row that the page is on. Mainly used for the html id and class tags.
        site_name (str):
            The name of the folder that the site is named after.
        site_output_folder (str): 
            The path to the output folder for the site.
    ### Returns:
        None
    """
    
    # -- Do not change this log code:
    # -- Initialise logging:
    log = logging.getLogger(f"{os.getenv('SCRAPER_APP_NAME')}.sites.{site_name}.{__name__}.{inspect.stack()[0][3]}.{row_details.nickname}")
    
    log.info(f"Processing soup.")
    
    # #################################################################### #
    #                                                                      #
    # Overview:                                                            #
    #                                                                      #
    # Place your code below this box to process the page into whatever     #
    # format(s) you would like.                                            #
    #                                                                      #
    # To add logging, use the log variable with the level and message      #
    # you want to add. For example: log.info(f"Processing soup.").         #
    #                                                                      #
    # The scraped HTML is stored in a parameter / argument called soup.    #
    # Use this to access any data that was scraped and then do what you    #
    # need with it.                                                        #
    #                                                                      #
    # There are two export functions available, export_to_csv and          #
    # export_to_excel. You can add your own if you need something else.    #
    # If you do make your own, please store them in the export_files.py    #
    # file in the modules folder to make reusability easier.               #
    #                                                                      #
    # If you would like to see an example, please take a look at the       #
    # generic_one_table processor.py file.                                 #
    #                                                                      #
    # #################################################################### #
    
    
        
    
    return